import React, { useState, useEffect, useCallback } from "react";
import { Plus, Filter, Search } from "lucide-react";
import { ApiRequest } from "../../services/apiRequest";
import ProgramCard from "../../components/programCenter/programCard";
import ProgramFilter from "../../components/programCenter/filter";
import AddProgramModal from "../../components/programCenter/addProgram/addProgram";
import { filterProgramsByUser } from "../../utils/approvalUtils";
import { determineProgramStatus } from "../../utils/programStatus";
import Pagination from "../../components/common/pagination";
import { useLocation } from "react-router-dom";
import ConfirmDeleteModal from "../../components/common/ConfirmDeleteModal";
import { fetchAllPrograms } from "../../services/program/programService";

const ProgramCenter = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAddModalSpecial, setshowAddModalSpecial] = useState();
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterData, setFilterData] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [activeTab, setActiveTab] = useState("Active");
  const [selectedProgram, setSelectedProgram] = useState(null);
  const [showDelete, setShowDelete] = useState(false);
  const [areaMap, setAreaMap] = useState({});

  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const filter = params.get("filter");
    const tab = params.get("tab");

    if (tab) {
      setActiveTab(tab);
    }

    if (filter === "7days") {
      setActiveTab("Expired Soon");
      setFilterData({ expSoonType: "H7-H2" });
      setPage(1);
    }

    if (filter === "1day") {
      setActiveTab("Expired Soon");
      setFilterData({ expSoonType: "H1" });
      setPage(1);
    }
  }, [location.search]);

  // Pagination
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [limit, setLimit] = useState(10);

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;

      if (width < 640) {
        setLimit(3); // mobile
      } else if (width < 1024) {
        setLimit(5); // tablet
      } else {
        setLimit(10); // desktop
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const fetchAreas = async () => {
      try {
        const res = await ApiRequest({
          url: "/areas/all",
          method: "GET",
        });

        if (res.status === "success") {
          const map = {};
          res.data.forEach((area) => {
            map[area.area_id] = area.name; // ✅ FIX
          });
          setAreaMap(map);
        }
      } catch (err) {
        console.error("Failed fetch areas:", err);
      }
    };

    fetchAreas();
  }, []);

  /* -------------------------------------------------------------------------- */
  /*                              TAB FILTER                                    */
  /* -------------------------------------------------------------------------- */

  const filteredPrograms = programs;
  // Karena tab filtering sudah dilakukan di fetch,
  // kalau mau dipindah ke sini juga bisa, tapi untuk sekarang cukup ini.

  const start = (page - 1) * limit;
  const paginatedPrograms = filteredPrograms.slice(start, start + limit);

  useEffect(() => {
    setTotalPage(Math.ceil(filteredPrograms.length / limit));
  }, [filteredPrograms, limit]);

  useEffect(() => {
    setPage(1);
  }, [search, filterData, activeTab]);

  // === Fetch Profile & Programs ===
  const fetchProfileAndPrograms = useCallback(async () => {
    setLoading(true);

    try {
      const profileRes = await ApiRequest({
        url: "/profile/me",
        method: "GET",
      });
      const profile = profileRes.status === "success" ? profileRes.data : null;
      setUserProfile(profile);

      const rawPrograms = await fetchAllPrograms({
        search,
        filters: filterData || {},
      });

      const userCache = {};
      const detailCache = {};

      const formatted = await Promise.all(
        rawPrograms.map(async (item) => {
          let uploaderId =
            item.uploader_id || item.user_id || item.created_by || null;

          let uploaderImage = item.uploader_image || null;
          let uploaderName = item.uploader_name || null;

          let areaName = "All Area";
          let programAreas = [];

          // ✅ TARUH DI SINI
          let programApprovals = [];

          try {
            if (!detailCache[item.program_id]) {
              const detailRes = await ApiRequest({
                url: `/programs/detail/${item.program_id}`,
                method: "GET",
              });

              detailCache[item.program_id] = detailRes?.data || {};
            }

            const detailData = detailCache[item.program_id];
            const detailProgram = detailData?.program || {};

            programAreas = detailData?.program_areas || [];

            // ✅ JANGAN const lagi
            programApprovals = detailData?.program_approvals || [];

            if (!uploaderId) {
              uploaderId = detailProgram.user_id ?? null;
            }

            const totalMasterArea = Object.keys(areaMap).length;

            if (programAreas.length === 0) {
              areaName = "All Area";
            } else if (programAreas.length === totalMasterArea) {
              areaName = "All Area";
            } else if (programAreas.length > 0 && programAreas.length <= 10) {
              const areaNames = programAreas
                .map((a) => areaMap[a.area_id])
                .filter(Boolean);

              areaName = areaNames.length ? areaNames.join(", ") : "All Area";
            }

            if (uploaderId && (!uploaderImage || !uploaderName)) {
              if (!userCache[uploaderId]) {
                const userRes = await ApiRequest({
                  url: `/users/detail/${uploaderId}`,
                  method: "GET",
                });

                userCache[uploaderId] = userRes?.data || {};
              }

              const userData = userCache[uploaderId];

              uploaderImage = userData?.image_url ?? null;

              uploaderName =
                userData?.name || userData?.full_name || "Unknown User";
            }
          } catch (err) {
            console.warn(`Failed enrich program ${item.program_id}`, err);
          }

          const statusFE =
            item.status === "expired"
              ? "Expired"
              : determineProgramStatus({
                  ...item,
                  statusRaw: item.status,
                });

          return {
            ...item,

            id: item.program_id,
            name: item.name,
            no: item.program_code,
            area: areaName,

            status: statusFE,
            statusRaw: item.status,

            // ✅ sekarang mengambil dari DETAIL
            approvals: programApprovals,

            uploader_id: uploaderId,
            uploader_image: uploaderImage,
            uploader_name: uploaderName,

            program_areas: programAreas,
          };
        }),
      );

      let finalPrograms = formatted;

      if (filterData?.expSoonType) {
        finalPrograms = finalPrograms.filter((program) => {
          const endDate = new Date(program.period_end);
          const today = new Date();
          const diffDays = Math.ceil((endDate - today) / (1000 * 60 * 60 * 24));

          if (filterData.expSoonType === "H7-H2") {
            return diffDays <= 7 && diffDays >= 2;
          }
          if (filterData.expSoonType === "H1") {
            return diffDays === 1;
          }
          return true;
        });
      }

      if (activeTab === "Active") {
        finalPrograms = finalPrograms.filter(
          (p) => p.status === "Active" || p.status === "Expired Soon",
        );
      }

      if (activeTab === "Expired Soon") {
        finalPrograms = finalPrograms.filter(
          (p) => p.status === "Expired Soon",
        );
      }

      if (activeTab === "Expired") {
        finalPrograms = finalPrograms.filter((p) => p.statusRaw === "expired");
      }

      if (activeTab === "Rejected") {
        finalPrograms = finalPrograms.filter((p) => p.status === "Rejected");
      }

      if (activeTab === "Waiting Approve") {
        finalPrograms = finalPrograms.filter(
          (p) => p.status === "Waiting Approve",
        );
      }

      if (
        profile &&
        activeTab !== "Expired" &&
        activeTab !== "Active" &&
        activeTab !== "Expired Soon"
      ) {
        finalPrograms = filterProgramsByUser(
          finalPrograms,
          profile,
          activeTab,
          filterData?.expSoonType,
        );
      }

      setPrograms(finalPrograms);
    } catch (err) {
      console.error("Gagal ambil data programs:", err.message);
      setPrograms([]);
    } finally {
      setLoading(false);
    }
  }, [search, filterData, activeTab, areaMap]);

  // === Trigger Fetch ===
  useEffect(() => {
    const delay = setTimeout(() => {
      fetchProfileAndPrograms();
    }, 400);

    return () => clearTimeout(delay);
  }, [fetchProfileAndPrograms]);

  const handleAfterAdd = () => {
    setShowAddModal(false);
    fetchProfileAndPrograms(); // refresh otomatis
  };

  const formatDate = (d) => {
    if (!d) return "";
    const date = new Date(d);
    return date.toISOString().split("T")[0];
  };

  const applyFilter = (filter) => {
    // === Exp Soon ONLY (FE Filter)
    if (filter?.filterType === "expSoon") {
      setActiveTab("Expired Soon");
      setFilterData({ expSoonType: filter.expSoonType });
      setPage(1);
      return;
    }

    // === Program Filter Uses API Params
    if (filter?.filterType === "program") {
      const params = {
        search: "",
        program_channel_id: filter.channel_id || "",
        program_category_id: filter.program_id || "",
        area_id: filter.area_id || "",
        start_date: formatDate(filter.startDate),
        end_date: formatDate(filter.endDate),
        sort: "program_id asc",
      };

      // Save program filtering state
      setFilterData({
        ...params,
        expSoonType: filterData?.expSoonType, // keep expSoon if exists
      });

      // Reset page
      setPage(1);
      return;
    }

    // === Reset Filter (Program Filter Only)
    if (filter?.filterType === "programReset") {
      setFilterData({
        expSoonType: filterData?.expSoonType || "", // keep expSoon
      });
      setPage(1);
      return;
    }
  };

  const handlePageChange = (newPage) => {
    if (newPage < 1 || newPage > totalPage) return;
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: "smooth" }); // optional
  };

  // 🎨 Header color mapping per tab
  const headerColorByTab = {
    Active: {
      bg: "#A3D977",
      text: "#1F4D2B",
    },
    "Waiting Approve": {
      bg: "#D6E4FF", // soft blue
      text: "#1E40AF", // deep blue
    },
    Rejected: {
      bg: "#FFD6A6",
      text: "#7A3E00",
    },
    Expired: {
      bg: "#E66C63",
      text: "#5A0D0D",
    },
  };

  // default color
  let headerColors = headerColorByTab[activeTab] || headerColorByTab.Active;

  // 🔥 SPECIAL CASE: Expired Soon
  if (activeTab === "Expired Soon") {
    if (filterData?.expSoonType === "H1") {
      // 🔴 H-1
      headerColors = {
        bg: "#E66C63",
        text: "#5A0D0D",
      };
    } else {
      // 🟡 H-7 s/d H-2 & default Expired Soon
      headerColors = {
        bg: "#EDD967",
        text: "#5A4A00",
      };
    }
  }

  const handleDeleteProgram = (program) => {
    setSelectedProgram(program);
    setShowDelete(true);
  };

  const confirmDeleteProgram = async () => {
    if (!selectedProgram?.program_id) return;

    try {
      await ApiRequest({
        url: `/programs/delete/${selectedProgram.program_id}`,
        method: "DELETE",
      });

      setShowDelete(false);
      setSelectedProgram(null);

      // refresh list
      fetchProfileAndPrograms();
    } catch (err) {
      console.error("Gagal delete program:", err);
      alert("Failed to delete program");
    }
  };

  // === Render ===
  return (
    <div className="w-full px-4 mx-auto max-w-[1400px] /* HP */ sm:px-1 tablet lg:px-1 laptop xl:px-1 desktop besar 2xl:px-1 layar">
      {/* HEADER */}
      <div className="flex flex-col gap-4 mb-8 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-xl font-semibold sm:text-2xl text-brand-first">
          Program Center
        </h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm text-white transition bg-brand-first sm:px-5 sm:py-3 rounded-xl sm:text-base w-fit hover:bg-brand-secondary"
        >
          <Plus size={18} /> Add Program
        </button>
      </div>

      {showAddModal && (
        <AddProgramModal
          onClose={() => setShowAddModal(false)}
          onSuccess={handleAfterAdd}
        />
      )}

      {/* SEARCH BAR */}
      <div className="flex flex-col gap-4 mb-8 lg:flex-row lg:items-center">
        {/* ===== ROW 1 (Mobile & Tablet) : Search + Filter ===== */}
        <div className="flex items-center w-full gap-3 lg:w-auto">
          {/* SEARCH */}
          <div className="flex items-center flex-1 px-4 py-3 border-2 shadow-sm bg-surface-card border-surface-border rounded-xl h-[42px] lg:w-1/3">
            <Search size={18} className="mr-2 text-text-light" />
            <input
              type="text"
              placeholder="Letter Search"
              className="w-full text-sm bg-transparent outline-none text-text-primary"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* FILTER ICON */}
          <button
            onClick={() => setShowFilterModal(true)}
            className="flex items-center justify-center transition border shadow-sm h-[42px] w-[42px] rounded-2xl bg-surface-background text-brand-first border-surface-border hover:shadow-md"
          >
            <Filter size={17} />
          </button>
        </div>

        {/* ===== ROW 2 (Mobile & Tablet) : Tabs ===== */}
        <div className="flex w-full gap-3 overflow-x-auto lg:flex-1 lg:justify-end">
          {[
            "Active",
            "Expired Soon",
            "Waiting Approve",
            "Rejected",
            "Expired",
          ].map((tab) => (
            // {["Active", "Expired Soon", "Expired"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-2.5 rounded-full text-[13px] font-semibold transition-all whitespace-nowrap ${
                activeTab === tab
                  ? "bg-surface-background border-2 border-brand-first text-brand-first"
                  : "bg-surface-background text-brand-first border border-surface-border"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Section Header */}
      <div
        className="py-2 mb-4 text-center transition-all shadow-sm rounded-xl"
        style={{
          backgroundColor: headerColors.bg,
          color: headerColors.text,
        }}
      >
        <p className="text-sm font-semibold">Program {activeTab}</p>
      </div>

      {/* List */}
      <div className="p-4">
        {loading ? (
          <div className="flex items-center justify-center h-[200px]">
            <p className="text-sm text-text-light animate-pulse">
              Loading Programs...
            </p>
          </div>
        ) : programs.length > 0 ? (
          <div className="space-y-3">
            {paginatedPrograms.map((item, i) => (
              <ProgramCard
                key={i}
                {...item}
                userProfile={userProfile}
                activeTab={activeTab}
                uploader_name={item.uploader_name}
                uploader_image={item.uploader_image}
                onDelete={handleDeleteProgram} // 🔥 WAJIB
              />
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-[200px]">
            <p className="text-sm text-text-light">No Program Found</p>
          </div>
        )}
      </div>

      {!loading && programs.length > 0 && totalPage > 1 && (
        <Pagination
          current={page}
          total={totalPage}
          onChange={handlePageChange}
        />
      )}

      {showFilterModal && (
        <ProgramFilter
          onClose={() => setShowFilterModal(false)}
          onApply={applyFilter}
        />
      )}

      <ConfirmDeleteModal
        open={showDelete}
        onCancel={() => {
          setShowDelete(false);
          setSelectedProgram(null);
        }}
        onConfirm={confirmDeleteProgram}
      />
    </div>
  );
};

export default ProgramCenter;
